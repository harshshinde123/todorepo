import React, { useState } from 'react';
import TaskForm from './TaskForm';

const TaskList = ({ tasks, onEdit, onDelete, onAddTask }) => {
  const [showForm, setShowForm] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTasks, setSelectedTasks] = useState({});

  const handleAddTask = () => {
    setCurrentTask(null);
    setShowForm(true);
  };

  const handleEditTask = (task) => {
    setCurrentTask(task);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setCurrentTask(null);
  };

  const handleCheckboxChange = (taskId) => {
    setSelectedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  const filteredTasks = tasks.filter(task =>
    task.assignedTo.toLowerCase().includes(searchQuery.toLowerCase()) ||
    task.comments.toLowerCase().includes(searchQuery.toLowerCase()) ||
    task.status.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen relative">
      <div className="bg-gray-200 p-4 mb-4">
        <h1 className="text-green-600 text-lg font-bold">Tasks</h1>
        <p className="text-gray-500 text-xxs">{filteredTasks.length} records</p>
        <div className="flex justify-between items-center mb-4">
          <div className="flex-grow" />
          <div className="flex">
            <button
              className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded mr-2"
              onClick={handleAddTask}
            >
              New Task
            </button>
          </div>
          <div className="relative w-1/3 ml-4">
            <input
              type="text"
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full p-2 pl-10 border border-gray-300 rounded"
            />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto flex-grow">
        <table className="min-w-full bg-white border border-gray-200">
          <thead>
            <tr className="text-center">
              <th className="py-2 px-4 border-b">
                <input type="checkbox" />
              </th>
              <th className="py-2 px-4 border-b">Assigned To</th>
              <th className="py-2 px-4 border-b">Status</th>
              <th className="py-2 px-4 border-b">Due Date</th>
              <th className="py-2 px-4 border-b">Priority</th>
              <th className="py-2 px-4 border-b">Comments</th>
              <th className="py-2 px-4 border-b">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredTasks.map((task) => (
              <tr key={task.id}>
                <td className="py-2 px-4 border-b">
                  <input
                    type="checkbox"
                    checked={!!selectedTasks[task.id]}
                    onChange={() => handleCheckboxChange(task.id)}
                  />
                </td>
                <td className="py-2 px-4 border-b">{task.assignedTo}</td>
                <td className="py-2 px-4 border-b">{task.status}</td>
                <td className="py-2 px-4 border-b">{task.dueDate}</td>
                <td className="py-2 px-4 border-b">{task.priority}</td>
                <td className="py-2 px-4 border-b">{task.comments}</td>
                <td className="py-2 px-4 border-b">
                  <button
                    onClick={() => handleEditTask(task)}
                    className="bg-blue-500 text-white px-2 py-1 rounded"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => onDelete(task.id)}
                    className="bg-red-500 text-white px-2 py-1 rounded ml-2"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
            <TaskForm
              addTask={onAddTask}
              currentTask={currentTask}
              updateTask={onEdit}
              setCurrentTask={setCurrentTask}
              onClose={handleCloseForm}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskList;
