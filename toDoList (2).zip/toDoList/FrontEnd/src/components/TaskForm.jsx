import React, { useState, useEffect } from 'react';

const TaskForm = ({ addTask, currentTask, updateTask, setCurrentTask, onClose }) => {
  const [assignedTo, setAssignedTo] = useState('');
  const [status, setStatus] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('');
  const [comments, setComments] = useState('');

  useEffect(() => {
    if (currentTask) {
      setAssignedTo(currentTask.assignedTo);
      setStatus(currentTask.status);
      setDueDate(currentTask.dueDate);
      setPriority(currentTask.priority);
      setComments(currentTask.comments);
    } else {
      resetForm();
    }
  }, [currentTask]);

  const resetForm = () => {
    setAssignedTo('');
    setStatus('');
    setDueDate('');
    setPriority('');
    setComments('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!comments.trim()) {
      return; // Prevent empty comments
    }

    const taskData = {
      id: currentTask ? currentTask.id : Date.now(), // Use a timestamp for a new ID
      assignedTo,
      status,
      dueDate,
      priority,
      comments,
    };

    if (currentTask) {
      updateTask(taskData);
    } else {
      addTask(taskData);
    }

    resetForm();
    setCurrentTask(null);
    onClose(); // Close form on submit
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <input
        type="text"
        value={assignedTo}
        onChange={(e) => setAssignedTo(e.target.value)}
        placeholder="Assigned To"
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <input
        type="text"
        value={status}
        onChange={(e) => setStatus(e.target.value)}
        placeholder="Status"
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <input
        type="date"
        value={dueDate}
        onChange={(e) => setDueDate(e.target.value)}
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <input
        type="text"
        value={priority}
        onChange={(e) => setPriority(e.target.value)}
        placeholder="Priority"
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <textarea
        value={comments}
        onChange={(e) => setComments(e.target.value)}
        placeholder="Comments"
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <div className="flex justify-between">
        <button
          type="button"
          className="bg-red-500 text-white py-2 px-4 rounded"
          onClick={onClose}
        >
          Cancel
        </button>
        <button type="submit" className="bg-blue-500 text-white py-2 px-4 rounded">
          {currentTask ? 'Update Task' : 'Add Task'}
        </button>
      </div>
    </form>
  );
};

export default TaskForm;
