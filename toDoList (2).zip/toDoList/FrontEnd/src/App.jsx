import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import TaskList from './components/TaskList';

const App = () => {
  const [tasks, setTasks] = useState([]);

  // Fetch tasks from the backend
  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:8080/list/get/{id}'); 
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  // Add Task
  const addTask = async (taskData) => {
    try {
      const response = await axios.post('http://localhost:8080/list/add', taskData);
      setTasks([...tasks, response.data]);
    } catch (error) {
      console.error('Error adding task:', error);
    }
  };

  // Edit Task
  const editTask = async (updatedTask) => {
    try {
      const response = await axios.put('http://localhost:8080/list/update/{Id}', updatedTask);
      setTasks(tasks.map(task => (task.id === updatedTask.id ? response.data : task)));
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  // Delete Task
  const deleteTask = async (taskId) => {
    try {
      await axios.delete('http://localhost:8080/list/delete/{id}');
      setTasks(tasks.filter(task => task.id !== taskId));
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-gray-100">
        <nav className="bg-gray-200 p-4 text-green-600">
          <div className="container mx-auto flex justify-between">
            <h1 className="text-xl font-bold">Task Management</h1>
            <div className="flex space-x-4">
              <Link to="/tasks" className="hover:bg-blue-500 px-3 py-2 rounded">Task List</Link>
            </div>
          </div>
        </nav>

        <div className="flex-grow container mx-auto py-6">
          <Routes>
            <Route 
              path="/tasks" 
              element={
                <TaskList 
                  tasks={tasks} 
                  onAddTask={addTask} 
                  onEdit={editTask} 
                  onDelete={deleteTask} 
                />
              } 
            />
            <Route 
              path="*" 
              element={
                <TaskList 
                  tasks={tasks} 
                  onAddTask={addTask} 
                  onEdit={editTask} 
                  onDelete={deleteTask} 
                />
              } 
            />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
