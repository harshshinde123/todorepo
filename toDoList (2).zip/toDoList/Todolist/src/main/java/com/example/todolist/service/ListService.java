package com.example.todolist.service;

import com.example.todolist.Entity.Tdolist;

import java.util.List;

public interface ListService {

    public List<Tdolist> getAllList();
    public Tdolist addList(Tdolist tdolist);
    public Tdolist updateList( Long Id ,Tdolist tdolist);
    public void deleteListById(long id);
    public Tdolist getListById(long id);
}
