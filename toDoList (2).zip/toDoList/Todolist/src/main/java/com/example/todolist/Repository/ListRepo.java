package com.example.todolist.Repository;

import com.example.todolist.Entity.Tdolist;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ListRepo extends JpaRepository<Tdolist, Long> {


}

