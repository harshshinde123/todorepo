package com.example.todolist.Controller;

import com.example.todolist.Entity.Tdolist;
import com.example.todolist.service.ListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/list")
public class ListController {

    @Autowired
    private ListService listService;

    //add list to database
    @PostMapping("/add")
    @ResponseStatus( value = HttpStatus.CREATED)
    public Tdolist addList ( @RequestBody Tdolist tdolist)
    {
        return listService.addList(tdolist);
    }

    //get all list from database
    @GetMapping("/all")
    public Iterable<Tdolist> getAllList()
    {
        return listService.getAllList();
    }

    //update list in database
    @PutMapping("/update/{Id}")
    public Tdolist updateList  ( @PathVariable Long Id ,@RequestBody Tdolist tdolist)
    {
        return listService.updateList(Id,tdolist);
    }

    //delete list from database
    @DeleteMapping("/delete/{id}")
    public void deleteListById(@PathVariable long id)
    {
        listService.deleteListById(id);
    }

    //get list by id from database
    @GetMapping("/get/{id}")
    public Tdolist getListById(@PathVariable long id)
    {
        return listService.getListById(id);
    }
}
