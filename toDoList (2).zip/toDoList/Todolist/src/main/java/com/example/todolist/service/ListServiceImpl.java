package com.example.todolist.service;

import com.example.todolist.Entity.Tdolist;
import com.example.todolist.Repository.ListRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ListServiceImpl implements ListService {
    @Autowired
    private ListRepo listRepo;


    @Override
    public List<Tdolist> getAllList() {
        return List.of();
    }

    @Override
 public Tdolist addList(Tdolist tdolist) {
        return listRepo.save(tdolist);
    }



    @Override
    public Tdolist updateList( Long Id ,Tdolist tdolist) {

    Optional<Tdolist> list = listRepo.findById(Id);
    if(list.isPresent()){
        Tdolist newlist = list.get();
        newlist.setAssignTo(tdolist.getAssignTo());
        newlist.setStatus(tdolist.getStatus());
        newlist.setPriority(tdolist.getPriority());
        newlist.setDueDate(tdolist.getDueDate());
        newlist.setDescription(tdolist.getDescription());
        return listRepo.save(newlist);
    }
        return null;
    }

    @Override
    public void deleteListById(long id) {
    listRepo.deleteById(id);

    }

    @Override
    public Tdolist getListById(long id) {
        return listRepo.findById(id).orElseThrow(()->
                new RuntimeException("List with id " + id + " not found"));
    }
}
